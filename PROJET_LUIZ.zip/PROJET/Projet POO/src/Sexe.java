enum Sexe {MASCULIN, FEMININ};
